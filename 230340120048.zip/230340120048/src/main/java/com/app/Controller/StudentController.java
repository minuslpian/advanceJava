package com.app.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.Dto.ApiResponse;
import com.app.Dto.StudentDto;
import com.app.Services.StudentService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

//Rest controller which will call methods as per uri path
@RestController
@RequestMapping("/students")
public class StudentController {

	// creating controller dependency which is service layer interface
	@Autowired
	private StudentService studentService;

	public StudentController() {
		System.out.println("In constructor of " + getClass());
	}

	// creating method which will be called to create new student entry in mysql
	// database
	// @Postmapping as request sent by client is of type post , @RequestBody for
	// un marshaling from JSON to java and @Valid for validations
	@PostMapping
	public ResponseEntity<?> addNewStudent(@RequestBody StudentDto newStudent) {
		try {
			System.out.println("in add new student "+ newStudent);
			return new ResponseEntity<>(studentService.createNewStudent(newStudent), HttpStatus.CREATED);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
		}
	}

	// creating a method which will retrieve specific student provided the id of the
	// student which will get received via path variable
	@GetMapping("/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable long id) {
		try {
			return new ResponseEntity<>(studentService.getStudentById(id), HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
		}
	}

	// creating a method which will retrieve all students
	@GetMapping
	public ResponseEntity<?> getAllStudents() {
		try {
			return new ResponseEntity<>(studentService.getAllStudents(), HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(new ApiResponse(e.getMessage()), HttpStatus.NOT_FOUND);
		}
	}

}
