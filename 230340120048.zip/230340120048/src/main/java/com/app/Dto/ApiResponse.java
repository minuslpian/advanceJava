package com.app.Dto;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
//An response for all types of exceptions
public class ApiResponse {
	private LocalDateTime timeStamp;
	private String message;

	public ApiResponse(String message) {

		this.message = message;
		this.timeStamp = LocalDateTime.now();
	}

}
