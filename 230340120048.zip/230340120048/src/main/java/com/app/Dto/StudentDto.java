package com.app.Dto;




import java.time.LocalDate;

import com.app.entities.Gender;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class StudentDto {
	private String name;

	

	private String email;

	private LocalDate birthDate;

	
	private Gender gender;

}
