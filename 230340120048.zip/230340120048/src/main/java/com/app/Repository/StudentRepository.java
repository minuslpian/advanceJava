package com.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.entities.Student;

// student repository which will be inheriting all properties of JPA repository in turn getting all APIs which help to connect to db
public interface StudentRepository extends JpaRepository<Student, Long> {

}
