package com.app.Services;

import java.util.List;

import com.app.Dto.StudentDto;

//Student Service interface which will create contract for implementation class
public interface StudentService {
	// method for creating new Student
	String createNewStudent(StudentDto newStudent);

	// method for retrieving Student by id
	StudentDto getStudentById(long id);

	// method for retrieving all students
	List<StudentDto> getAllStudents();
}
