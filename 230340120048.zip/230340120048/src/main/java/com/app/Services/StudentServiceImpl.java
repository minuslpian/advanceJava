package com.app.Services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Dto.StudentDto;
import com.app.Repository.StudentRepository;

import com.app.entities.Student;

import Custom_Exception.ResourceNotFoundException;

// creating a service layer implementation which is connection between repository and controller
@Service

//this annotation will create a new session from session factory, start a transaction
//and commit / roll back as per response from repository layer
@Transactional
public class StudentServiceImpl implements StudentService {

	// creating a dependency named StudentRepository which will hold connection to
	// database via JPA repository APIs
	@Autowired
	private StudentRepository studentRepo;

	// creating a dependency named ModelMapper which will map Entity to DTO and vice
	// versa
	@Autowired
	private ModelMapper mapper;

	// overriding method to create new student into database
	@Override
	public String createNewStudent(StudentDto newStudent) {
		Student student = studentRepo.save(mapper.map(newStudent, Student.class));
		return " New Student added by name " + student.getName();

	}

	// overriding method to retrieve specific student by their Id from database
	@Override
	public StudentDto getStudentById(long id) {
		Student student = studentRepo.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Invalid Student id. Not present in DataBase"));

		return mapper.map(student, StudentDto.class);
	}

	// overriding method to retrieve all students from database
	@Override
	public List<StudentDto> getAllStudents() {
		List<Student> students = studentRepo.findAll();
		List<StudentDto> studentsDto = new ArrayList<>();
		students.stream().forEach(student -> studentsDto.add(mapper.map(student, StudentDto.class)));
		return studentsDto;
	}

}
