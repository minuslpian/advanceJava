package com.app.entities;

//Enum type gender holding 3 objects
public enum Gender {
	MALE, FEMALE, OTHERS
}
