package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

//creating an Student entity which will be represented in database table as per javax annotations
@Entity
@Table(name = "students")
//Lombok annotations for creating no arg const, getter, setters, to string
@NoArgsConstructor
@Setter
@Getter
@ToString
public class Student {
	// Id which requires auto generation
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	// Name of the student
	@Column(name = "Name", length = 40)
	private String name;

	// Email of the student
	@Column(name = "Email", length = 20, unique = true)
	private String email;

	// BirthDate of the student
	@Column(name = "birth_date")
	private LocalDate birthDate;

	// Gender of the student
	@Enumerated(EnumType.STRING)
	@Column(name = "Gender")
	
	private Gender gender;

	// required arguments constructor
	public Student(String name, String email, LocalDate birthDate, Gender gender) {
		super();
		this.name = name;
		this.email = email;
		this.birthDate = birthDate;
		this.gender = gender;
	}

}
