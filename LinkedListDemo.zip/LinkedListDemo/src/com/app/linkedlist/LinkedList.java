package com.app.linkedlist;

public class LinkedList {
	private Node head;

//    private Node tail;
	public LinkedList() {
		head = null;
	}

	public void addAtEnd(int data) {
		Node newNode = new Node();
		newNode.setData(data);
		newNode.setNext(null);

		if (head == null) {
			head = newNode;
		} else {
			Node trav = head;
			while (trav.getNext() != null)
				trav = trav.getNext();
			trav.setNext(newNode);
		}
	}

	public void addAtBegin(int data) {
		Node newNode = new Node();
		newNode.setData(data);
		if (head == null) {
			head = newNode;
		} else {
			newNode.setNext(head);
			head = newNode;
		}
	}

	public void addAtPosition(int data, int pos) {
		Node newNode = new Node();
		newNode.setData(data);
		if (head == null) {
			head = newNode;
		} else {
			Node trav = head;
			for (int i = 1; i < pos - 1; i++) {
				trav = trav.getNext();
			}
			newNode.setNext(trav.getNext());
			trav.setNext(newNode);
		}
	}

	public void removeFromEnd() {
		Node trav = head;
		while (trav.getNext().getNext() != null) {
			trav = trav.getNext();
		}
		trav.setNext(null);

	}

	public void removeFromBegin() {
		if (head != null) {
			head = head.getNext();
		}
	}

	public void removeFromPosition(int pos) {
		Node trav = head;
		if (head.getNext() != null) {
			for (int i = 1; i < pos - 1; i++) {
				trav = trav.getNext();
			}
			trav.setNext(trav.getNext().getNext());

		} else {
			head = null;
		}
	}

	public void show() {
		Node trav = head;
		while (trav != null) {
			System.out.println(trav.getData() + " ");
			trav = trav.getNext();
		}
	}
}
